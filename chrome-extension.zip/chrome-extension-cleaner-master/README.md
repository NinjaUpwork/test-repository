# chrome-extension-cleaner
View and clean your malware extensions on chrome browser

Download or Clone this repo

To install all the dependencies type
    $ npm i 

To run the tests 
    $ npm test
    
To build the extension
    $ npm start
The extension will be built in 'dist/' directory
