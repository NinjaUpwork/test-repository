﻿(function() {
    'use strict';
    angular
        .module('jstube.chromeExtensionCleaner.popup',
        [
            'ngRoute',
            'ngSanitize',
            'jstube.chromeExtensionCleaner.common']);
}(window, angular));