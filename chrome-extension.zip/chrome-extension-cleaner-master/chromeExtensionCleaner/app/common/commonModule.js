﻿(function() {
    'use strict';
    angular
        .module('jstube.chromeExtensionCleaner.common',
            []);
}(window.angular));